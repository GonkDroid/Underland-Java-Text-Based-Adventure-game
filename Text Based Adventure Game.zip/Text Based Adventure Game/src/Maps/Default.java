package Maps;

public class Default {
		public Default(){
			
		}
}
