package Classes;

public class Atributes {
//		
//		int health;
//		int carryLoad;
//		int movementSpeed;
//		String dmgType;
//		int stealth;
//		int attackDmg;
		
//		public void setAtributes(){
//			health = 100;
//			carryLoad = 20;
//			movementSpeed = 30;
//			dmgType = "Slashing";
//			stealth = 1;
//			attackDmg = 3;
//		}
		
		public void Heavy(){
			//A tank kind of class that cannot deal a lot of damage but has the most HP and armor points in the game.
			int heavyHealth = 25;//HP
			int heavyCarryLoad = 400;//lbs
			int heavyMovementSpeed = 20;//FT. per turn
			String heavyDmgType = "Bludgeoning";//How the weapons deal dmg
			int heavyStealth = 3;//1-10, 1 being you will always be seen, 10 being you are a fucking ninja
			int heavyAttackDmg = 20;//1-100, 1 being I tickle you 100 being the most dmg you will ever be able to do
			
			
		}
		
		public void Mage(){
			//A lightly armored class with low HP, but can cast damaging spells and can enchant other items.

		}
		
		public void Priest(){
			//The only class in the game that can heal others, and also can change to it's pre-chosen form at will

		}
		
		public void Ranger(){
			//The ranged class in the game being the only one able to access bows and later on sniper riffles, and gets a buff to stealth but can only do a lot of damage from range.

		}
		
		public void Scout(){
			//This class can only carry light armor, but has a huge buff to stealth and movement speed.

		}
		
		public void Warrior(){
			//Warriors specialize in weapons and do the most damage out of another class, but get the worst stealth out of any other. Also, they can wield the rarest and most powerful melee weapons.

		}
}
