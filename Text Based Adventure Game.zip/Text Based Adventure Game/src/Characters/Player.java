package Characters;

public class Player {

}
